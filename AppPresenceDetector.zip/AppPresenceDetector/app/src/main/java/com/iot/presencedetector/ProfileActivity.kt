package com.iot.presencedetector

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.iot.presencedetector.service.FirebaseService
import kotlinx.coroutines.launch

class ProfileActivity : AppCompatActivity() {

    private lateinit var firebaseService: FirebaseService

    private lateinit var backButton: ImageButton
    private lateinit var emailTextView: TextView
    private lateinit var userIdTextView: TextView
    private lateinit var createdDateTextView: TextView
    private lateinit var logoutButton: Button
    private lateinit var deleteAccountButton: Button
    private lateinit var progressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        firebaseService = FirebaseService()

        initViews()
        loadUserData()
    }

    private fun initViews() {
        backButton = findViewById(R.id.backButton)
        emailTextView = findViewById(R.id.emailTextView)
        userIdTextView = findViewById(R.id.userIdTextView)
        createdDateTextView = findViewById(R.id.createdDateTextView)
        logoutButton = findViewById(R.id.logoutButton)
        deleteAccountButton = findViewById(R.id.deleteAccountButton)
        progressBar = findViewById(R.id.progressBar)

        backButton.setOnClickListener {
            finish()
        }

        logoutButton.setOnClickListener {
            logout()
        }

        deleteAccountButton.setOnClickListener {
            showDeleteAccountDialog()
        }
    }

    private fun loadUserData() {
        val currentUser = firebaseService.getCurrentUser()

        if (currentUser != null) {
            emailTextView.text = currentUser.email ?: "Sin email"
            userIdTextView.text = "ID: ${currentUser.uid}"

            val createdDate = currentUser.metadata?.creationTimestamp
            if (createdDate != null) {
                val date = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault())
                    .format(java.util.Date(createdDate))
                createdDateTextView.text = "Miembro desde: $date"
            } else {
                createdDateTextView.text = "Miembro desde: Desconocido"
            }
        } else {
            Toast.makeText(this, "Error: Usuario no encontrado", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun logout() {
        firebaseService.logout()
        startActivity(Intent(this, LoginActivity::class.java))
        finishAffinity() // Cierra todas las actividades
    }

    private fun showDeleteAccountDialog() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Eliminar Cuenta")
            .setMessage("¿Estás seguro de que deseas eliminar tu cuenta? Esta acción no se puede deshacer.")
            .setPositiveButton("Eliminar") { _, _ ->
                deleteAccount()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun deleteAccount() {
        progressBar.visibility = android.view.View.VISIBLE

        lifecycleScope.launch {
            val result = firebaseService.deleteAccount()

            progressBar.visibility = android.view.View.GONE

            result.onSuccess {
                Toast.makeText(
                    this@ProfileActivity,
                    "Cuenta eliminada exitosamente",
                    Toast.LENGTH_SHORT
                ).show()
                startActivity(Intent(this@ProfileActivity, LoginActivity::class.java))
                finishAffinity()
            }.onFailure { e ->
                Toast.makeText(
                    this@ProfileActivity,
                    "Error al eliminar cuenta: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}