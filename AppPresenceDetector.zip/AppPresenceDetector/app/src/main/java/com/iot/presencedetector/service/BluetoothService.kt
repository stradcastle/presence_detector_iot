package com.iot.presencedetector.service

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.app.ActivityCompat
import com.iot.presencedetector.model.DeviceStatus
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONObject
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

/**
 * Servicio para manejar la comunicación Bluetooth con el ESP32
 */
class BluetoothService(private val context: Context) {

    companion object {
        private const val TAG = "BluetoothService"
        private val MY_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private const val DEVICE_NAME = "ESP32_Presence_Detector"
    }

    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private var bluetoothSocket: BluetoothSocket? = null
    private var inputStream: InputStream? = null
    private var outputStream: OutputStream? = null
    private var connectionJob: Job? = null
    private var readJob: Job? = null

    private val _connectionState = MutableStateFlow(ConnectionState.DISCONNECTED)
    val connectionState: StateFlow<ConnectionState> = _connectionState

    private val _deviceStatus = MutableStateFlow(DeviceStatus())
    val deviceStatus: StateFlow<DeviceStatus> = _deviceStatus

    private val _lastMessage = MutableStateFlow("")
    val lastMessage: StateFlow<String> = _lastMessage

    enum class ConnectionState {
        DISCONNECTED, CONNECTING, CONNECTED, ERROR
    }

    /**
     * Verifica si el Bluetooth está habilitado
     */
    fun isBluetoothEnabled(): Boolean {
        return bluetoothAdapter?.isEnabled ?: false
    }

    /**
     * Obtiene la lista de dispositivos emparejados
     */
    @SuppressLint("MissingPermission")
    fun getPairedDevices(): List<BluetoothDevice> {
        if (!hasBluetoothPermission()) {
            Log.w(TAG, "No se tienen permisos de Bluetooth")
            return emptyList()
        }
        return bluetoothAdapter?.bondedDevices?.toList() ?: emptyList()
    }

    /**
     * Conecta con un dispositivo Bluetooth
     */
    @SuppressLint("MissingPermission")
    fun connect(device: BluetoothDevice) {
        if (!hasBluetoothPermission()) {
            _connectionState.value = ConnectionState.ERROR
            return
        }

        connectionJob = CoroutineScope(Dispatchers.IO).launch {
            try {
                _connectionState.value = ConnectionState.CONNECTING

                // Cancelar el descubrimiento de dispositivos si está activo
                bluetoothAdapter?.cancelDiscovery()

                // Crear socket y conectar
                bluetoothSocket = device.createRfcommSocketToServiceRecord(MY_UUID)
                bluetoothSocket?.connect()

                // Obtener streams
                inputStream = bluetoothSocket?.inputStream
                outputStream = bluetoothSocket?.outputStream

                _connectionState.value = ConnectionState.CONNECTED
                _deviceStatus.value = _deviceStatus.value.copy(
                    connected = true,
                    deviceName = device.name ?: "Unknown"
                )

                Log.i(TAG, "Conectado a ${device.name}")

                // Iniciar lectura de datos
                startReading()

                // Solicitar estado inicial
                delay(1000)
                sendCommand("ESTADO")

            } catch (e: IOException) {
                Log.e(TAG, "Error al conectar: ${e.message}", e)
                _connectionState.value = ConnectionState.ERROR
                disconnect()
            }
        }
    }

    /**
     * Inicia la lectura continua de datos del dispositivo
     */
    private fun startReading() {
        readJob = CoroutineScope(Dispatchers.IO).launch {
            val buffer = ByteArray(1024)

            while (isActive && connectionState.value == ConnectionState.CONNECTED) {
                try {
                    val bytes = inputStream?.read(buffer) ?: -1
                    if (bytes > 0) {
                        val message = String(buffer, 0, bytes).trim()
                        withContext(Dispatchers.Main) {
                            processMessage(message)
                        }
                    }
                } catch (e: IOException) {
                    Log.e(TAG, "Error al leer: ${e.message}")
                    break
                }
            }
        }
    }

    /**
     * Procesa los mensajes recibidos del ESP32
     */
    private fun processMessage(message: String) {
        Log.d(TAG, "Mensaje recibido: $message")
        _lastMessage.value = message

        when {
            message.startsWith("{") && message.endsWith("}") -> {
                // Mensaje JSON con estado
                try {
                    val json = JSONObject(message)
                    val status = DeviceStatus(
                        estado = json.optInt("estado", 0),
                        estadoTexto = json.optString("estadoTexto", "APAGADO"),
                        movimiento = json.optBoolean("movimiento", false),
                        ledRojo = json.optInt("ledRojo", 0) == 1,
                        ledVerde = json.optInt("ledVerde", 0) == 1,
                        ledAzul = json.optInt("ledAzul", 0) == 1,
                        timestamp = json.optLong("timestamp", 0),
                        connected = true,
                        deviceName = _deviceStatus.value.deviceName
                    )
                    _deviceStatus.value = status
                } catch (e: Exception) {
                    Log.e(TAG, "Error al parsear JSON: ${e.message}")
                }
            }
            message.startsWith("ALERT:") -> {
                Log.w(TAG, "Alerta recibida: $message")
            }
            message.startsWith("INFO:") -> {
                Log.i(TAG, "Info recibida: $message")
            }
            message.startsWith("OK:") -> {
                Log.i(TAG, "Confirmación recibida: $message")
            }
            message.startsWith("ERROR:") -> {
                Log.e(TAG, "Error recibido: $message")
            }
        }
    }

    /**
     * Envía un comando al ESP32
     */
    fun sendCommand(command: String): Boolean {
        return try {
            outputStream?.write("$command\n".toByteArray())
            outputStream?.flush()
            Log.i(TAG, "Comando enviado: $command")
            true
        } catch (e: IOException) {
            Log.e(TAG, "Error al enviar comando: ${e.message}", e)
            false
        }
    }

    /**
     * Cambia el estado del dispositivo
     */
    fun changeState(state: Int) {
        val command = when (state) {
            0 -> "ESTADO0"
            1 -> "ESTADO1"
            2 -> "ESTADO2"
            else -> return
        }
        sendCommand(command)
    }

    /**
     * Solicita el estado actual del dispositivo
     */
    fun requestStatus() {
        sendCommand("ESTADO")
    }

    /**
     * Desconecta del dispositivo Bluetooth
     */
    fun disconnect() {
        connectionJob?.cancel()
        readJob?.cancel()

        try {
            inputStream?.close()
            outputStream?.close()
            bluetoothSocket?.close()
        } catch (e: IOException) {
            Log.e(TAG, "Error al cerrar conexión: ${e.message}")
        }

        inputStream = null
        outputStream = null
        bluetoothSocket = null

        _connectionState.value = ConnectionState.DISCONNECTED
        _deviceStatus.value = _deviceStatus.value.copy(connected = false)

        Log.i(TAG, "Desconectado")
    }

    /**
     * Verifica si se tienen los permisos necesarios de Bluetooth
     */
    private fun hasBluetoothPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.BLUETOOTH
            ) == PackageManager.PERMISSION_GRANTED
        }
    }
}
