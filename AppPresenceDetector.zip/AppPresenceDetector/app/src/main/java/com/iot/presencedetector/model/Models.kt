package com.iot.presencedetector.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId

/**
 * Modelo de datos para eventos del sistema
 */
data class Event(
    @DocumentId
    val id: String = "",
    val userId: String = "",
    val eventType: String = "", // "MOVIMIENTO_DETECTADO", "CAMBIO_ESTADO", "CONEXION", "DESCONEXION"
    val estado: Int = 0,
    val estadoTexto: String = "",
    val movimiento: Boolean = false,
    val timestamp: Timestamp = Timestamp.now(),
    val deviceName: String = ""
) {
    // Constructor sin argumentos requerido por Firestore
    constructor() : this("", "", "", 0, "", false, Timestamp.now(), "")
}

/**
 * Modelo de estado del dispositivo
 */
data class DeviceStatus(
    val estado: Int = 0,
    val estadoTexto: String = "APAGADO",
    val movimiento: Boolean = false,
    val ledRojo: Boolean = false,
    val ledVerde: Boolean = false,
    val ledAzul: Boolean = false,
    val timestamp: Long = 0L,
    val connected: Boolean = false,
    val deviceName: String = ""
)

/**
 * Modelo de usuario
 */
data class User(
    @DocumentId
    val id: String = "",
    val email: String = "",
    val displayName: String = "",
    val createdAt: Timestamp = Timestamp.now(),
    val lastLogin: Timestamp = Timestamp.now()
) {
    constructor() : this("", "", "", Timestamp.now(), Timestamp.now())
}
