package com.iot.presencedetector

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import com.iot.presencedetector.model.Event
import com.iot.presencedetector.service.BluetoothService
import com.iot.presencedetector.service.FirebaseService
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

class MainActivity : AppCompatActivity() {

    companion object {
        private const val REQUEST_BLUETOOTH_PERMISSIONS = 1
        private const val TEST_MODE = true // ✅ MODO DE PRUEBA ACTIVADO
    }

    private lateinit var bluetoothService: BluetoothService
    private lateinit var firebaseService: FirebaseService

    private lateinit var statusTextView: TextView
    private lateinit var connectionStatusTextView: TextView
    private lateinit var deviceNameTextView: TextView
    private lateinit var motionStatusTextView: TextView
    private lateinit var state0Button: Button
    private lateinit var state1Button: Button
    private lateinit var state2Button: Button
    private lateinit var connectButton: Button
    private lateinit var disconnectButton: Button
    private lateinit var ledIndicatorView: View
    private lateinit var refreshButton: Button

    // Variables para modo de prueba
    private var testConnected = false
    private var testState = 0
    private var testMotion = false
    private var testLedRed = false
    private var testLedGreen = false
    private var testLedBlue = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bluetoothService = BluetoothService(this)
        firebaseService = FirebaseService()

        initViews()

        if (TEST_MODE) {
            showTestModeMessage()
            initTestMode()
        } else {
            checkBluetoothPermissions()
            observeBluetoothState()
        }
    }

    private fun showTestModeMessage() {
        Toast.makeText(
            this,
            "🧪 MODO DE PRUEBA ACTIVADO - Sin Bluetooth Real",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun initViews() {
        statusTextView = findViewById(R.id.statusTextView)
        connectionStatusTextView = findViewById(R.id.connectionStatusTextView)
        deviceNameTextView = findViewById(R.id.deviceNameTextView)
        motionStatusTextView = findViewById(R.id.motionStatusTextView)
        state0Button = findViewById(R.id.state0Button)
        state1Button = findViewById(R.id.state1Button)
        state2Button = findViewById(R.id.state2Button)
        connectButton = findViewById(R.id.connectButton)
        disconnectButton = findViewById(R.id.disconnectButton)
        ledIndicatorView = findViewById(R.id.ledIndicatorView)
        refreshButton = findViewById(R.id.refreshButton)

        if (TEST_MODE) {
            // Modo de prueba: usar funciones simuladas
            state0Button.setOnClickListener { simulateChangeState(0) }
            state1Button.setOnClickListener { simulateChangeState(1) }
            state2Button.setOnClickListener { simulateChangeState(2) }
            connectButton.setOnClickListener { simulateConnect() }
            disconnectButton.setOnClickListener { simulateDisconnect() }
            refreshButton.setOnClickListener { simulateRefresh() }
        } else {
            // Modo normal: usar Bluetooth real
            state0Button.setOnClickListener { bluetoothService.changeState(0) }
            state1Button.setOnClickListener { bluetoothService.changeState(1) }
            state2Button.setOnClickListener { bluetoothService.changeState(2) }
            connectButton.setOnClickListener { showDeviceList() }
            disconnectButton.setOnClickListener { bluetoothService.disconnect() }
            refreshButton.setOnClickListener { bluetoothService.requestStatus() }
        }

        findViewById<Button>(R.id.menuButton).setOnClickListener {
            showMenuOptions()
        }
    }

    // ========== FUNCIONES DE MODO DE PRUEBA ==========

    private fun initTestMode() {
        // Configuración inicial en modo de prueba
        updateTestUI()
    }

    private fun simulateConnect() {
        // Simular lista de dispositivos
        val testDevices = arrayOf(
            "🧪 Dispositivo de Prueba 1",
            "🧪 Dispositivo de Prueba 2",
            "🧪 ESP32 Simulado",
            "🧪 Arduino HC-05"
        )

        AlertDialog.Builder(this)
            .setTitle("Dispositivos Simulados")
            .setItems(testDevices) { _, which ->
                val deviceName = testDevices[which]
                simulateConnecting(deviceName)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun simulateConnecting(deviceName: String) {
        // Simular proceso de conexión
        connectionStatusTextView.text = "Conectando..."
        connectionStatusTextView.setTextColor(getColor(android.R.color.holo_orange_dark))
        connectButton.isEnabled = false

        lifecycleScope.launch {
            delay(1500) // Simular tiempo de conexión
            testConnected = true
            deviceNameTextView.text = "Dispositivo: $deviceName"
            updateTestUI()
            Toast.makeText(
                this@MainActivity,
                "✅ Conectado a $deviceName",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun simulateDisconnect() {
        testConnected = false
        testState = 0
        testMotion = false
        updateTestUI()
        Toast.makeText(this, "Desconectado del dispositivo", Toast.LENGTH_SHORT).show()
    }

    private fun simulateChangeState(newState: Int) {
        testState = newState

        // Simular cambios de LED según el estado
        when (newState) {
            0 -> {
                testLedRed = true
                testLedGreen = false
                testLedBlue = false
            }
            1 -> {
                testLedRed = false
                testLedGreen = true
                testLedBlue = false
            }
            2 -> {
                testLedRed = false
                testLedGreen = false
                testLedBlue = true
            }
        }

        updateTestUI()
        Toast.makeText(this, "Estado cambiado a: $newState", Toast.LENGTH_SHORT).show()

        // Registrar evento en Firebase
        logTestEvent("CAMBIO_ESTADO", newState)
    }

    private fun simulateRefresh() {
        Toast.makeText(this, "Actualizando estado...", Toast.LENGTH_SHORT).show()

        lifecycleScope.launch {
            delay(500)

            // Simular detección aleatoria de movimiento (30% de probabilidad)
            testMotion = (0..100).random() < 30

            updateTestUI()

            if (testMotion) {
                Toast.makeText(
                    this@MainActivity,
                    "⚠️ ¡Movimiento detectado!",
                    Toast.LENGTH_SHORT
                ).show()
                logTestEvent("MOVIMIENTO_DETECTADO", testState)
            }
        }
    }

    private fun updateTestUI() {
        // Actualizar estado de conexión
        if (testConnected) {
            connectionStatusTextView.text = "Conectado (Modo Prueba)"
            connectionStatusTextView.setTextColor(getColor(android.R.color.holo_green_dark))
            connectButton.isEnabled = false
            disconnectButton.isEnabled = true
            enableControlButtons(true)
        } else {
            connectionStatusTextView.text = "Desconectado"
            connectionStatusTextView.setTextColor(getColor(android.R.color.holo_red_dark))
            deviceNameTextView.text = "Sin dispositivo"
            connectButton.isEnabled = true
            disconnectButton.isEnabled = false
            enableControlButtons(false)
        }

        // Actualizar estado del dispositivo
        val stateText = when (testState) {
            0 -> "Apagado/Inactivo"
            1 -> "Activo/Vigilancia"
            2 -> "Alarma/Alerta"
            else -> "Desconocido"
        }
        statusTextView.text = "Estado: $stateText"

        // Actualizar estado de movimiento
        motionStatusTextView.text = if (testMotion) {
            "⚠️ MOVIMIENTO DETECTADO"
        } else {
            "✓ Sin movimiento"
        }
        motionStatusTextView.setTextColor(
            if (testMotion) getColor(android.R.color.holo_red_dark)
            else getColor(android.R.color.holo_green_dark)
        )

        // Actualizar indicador LED
        val ledColor = when {
            testLedRed -> android.R.color.holo_red_dark
            testLedGreen -> android.R.color.holo_green_dark
            testLedBlue -> android.R.color.holo_blue_dark
            else -> android.R.color.darker_gray
        }
        ledIndicatorView.setBackgroundColor(getColor(ledColor))
    }

    private fun logTestEvent(eventType: String, state: Int) {
        lifecycleScope.launch {
            firebaseService.logEvent(
                eventType = eventType,
                estado = state,
                estadoTexto = when (state) {
                    0 -> "Apagado/Inactivo"
                    1 -> "Activo/Vigilancia"
                    2 -> "Alarma/Alerta"
                    else -> "Desconocido"
                },
                movimiento = testMotion,
                deviceName = "Dispositivo de Prueba"
            )
        }
    }

    // ========== FUNCIONES NORMALES (Bluetooth Real) ==========

    private fun observeBluetoothState() {
        lifecycleScope.launch {
            bluetoothService.connectionState.collect { state ->
                updateConnectionUI(state)
            }
        }

        lifecycleScope.launch {
            bluetoothService.deviceStatus.collect { status ->
                updateDeviceUI(status)

                if (status.movimiento) {
                    logEvent("MOVIMIENTO_DETECTADO", status)
                }
            }
        }
    }

    private fun updateConnectionUI(state: BluetoothService.ConnectionState) {
        when (state) {
            BluetoothService.ConnectionState.DISCONNECTED -> {
                connectionStatusTextView.text = "Desconectado"
                connectionStatusTextView.setTextColor(getColor(android.R.color.holo_red_dark))
                connectButton.isEnabled = true
                disconnectButton.isEnabled = false
                enableControlButtons(false)
            }
            BluetoothService.ConnectionState.CONNECTING -> {
                connectionStatusTextView.text = "Conectando..."
                connectionStatusTextView.setTextColor(getColor(android.R.color.holo_orange_dark))
                connectButton.isEnabled = false
                disconnectButton.isEnabled = false
                enableControlButtons(false)
            }
            BluetoothService.ConnectionState.CONNECTED -> {
                connectionStatusTextView.text = "Conectado"
                connectionStatusTextView.setTextColor(getColor(android.R.color.holo_green_dark))
                connectButton.isEnabled = false
                disconnectButton.isEnabled = true
                enableControlButtons(true)
            }
            BluetoothService.ConnectionState.ERROR -> {
                connectionStatusTextView.text = "Error de conexión"
                connectionStatusTextView.setTextColor(getColor(android.R.color.holo_red_dark))
                connectButton.isEnabled = true
                disconnectButton.isEnabled = false
                enableControlButtons(false)
                Toast.makeText(this, "Error al conectar con el dispositivo", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updateDeviceUI(status: com.iot.presencedetector.model.DeviceStatus) {
        statusTextView.text = "Estado: ${status.estadoTexto}"
        deviceNameTextView.text = if (status.deviceName.isNotEmpty()) {
            "Dispositivo: ${status.deviceName}"
        } else {
            "Sin dispositivo"
        }

        motionStatusTextView.text = if (status.movimiento) {
            "⚠️ MOVIMIENTO DETECTADO"
        } else {
            "✓ Sin movimiento"
        }

        motionStatusTextView.setTextColor(
            if (status.movimiento) getColor(android.R.color.holo_red_dark)
            else getColor(android.R.color.holo_green_dark)
        )

        val ledColor = when {
            status.ledRojo -> android.R.color.holo_red_dark
            status.ledVerde -> android.R.color.holo_green_dark
            status.ledAzul -> android.R.color.holo_blue_dark
            else -> android.R.color.darker_gray
        }
        ledIndicatorView.setBackgroundColor(getColor(ledColor))
    }

    private fun enableControlButtons(enabled: Boolean) {
        state0Button.isEnabled = enabled
        state1Button.isEnabled = enabled
        state2Button.isEnabled = enabled
        refreshButton.isEnabled = enabled
    }

    @SuppressLint("MissingPermission")
    private fun showDeviceList() {
        if (!bluetoothService.isBluetoothEnabled()) {
            Toast.makeText(this, "Bluetooth no está habilitado", Toast.LENGTH_SHORT).show()
            return
        }

        val devices = bluetoothService.getPairedDevices()

        if (devices.isEmpty()) {
            Toast.makeText(this, "No hay dispositivos emparejados", Toast.LENGTH_SHORT).show()
            return
        }

        val deviceNames = devices.map { it.name ?: "Unknown" }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Seleccionar Dispositivo")
            .setItems(deviceNames) { _, which ->
                bluetoothService.connect(devices[which])
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showMenuOptions() {
        val options = arrayOf("Perfil", "Historial de Eventos", "Cerrar Sesión")

        AlertDialog.Builder(this)
            .setTitle("Menú")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> startActivity(Intent(this, ProfileActivity::class.java))
                    1 -> startActivity(Intent(this, EventHistoryActivity::class.java))
                    2 -> logout()
                }
            }
            .show()
    }

    private fun logout() {
        if (!TEST_MODE) {
            bluetoothService.disconnect()
        }
        firebaseService.logout()
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }

    private fun logEvent(eventType: String, status: com.iot.presencedetector.model.DeviceStatus) {
        lifecycleScope.launch {
            firebaseService.logEvent(
                eventType = eventType,
                estado = status.estado,
                estadoTexto = status.estadoTexto,
                movimiento = status.movimiento,
                deviceName = status.deviceName
            )
        }
    }

    private fun checkBluetoothPermissions() {
        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.ACCESS_FINE_LOCATION
            )
        } else {
            arrayOf(
                Manifest.permission.BLUETOOTH,
                Manifest.permission.BLUETOOTH_ADMIN,
                Manifest.permission.ACCESS_FINE_LOCATION
            )
        }

        val missingPermissions = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missingPermissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(
                this,
                missingPermissions.toTypedArray(),
                REQUEST_BLUETOOTH_PERMISSIONS
            )
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (!TEST_MODE) {
            bluetoothService.disconnect()
        }
    }
}