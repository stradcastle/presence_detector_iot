package com.iot.presencedetector
import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton

class BluetoothDeviceListActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var scanButton: MaterialButton
    private lateinit var emptyStateLayout: LinearLayout
    private var bluetoothAdapter: BluetoothAdapter? = null
    private val deviceList = mutableListOf<BluetoothDevice>()

    companion object {
        const val EXTRA_DEVICE_ADDRESS = "device_address"
        const val EXTRA_DEVICE_NAME = "device_name"
        private const val REQUEST_BLUETOOTH_PERMISSIONS = 1
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bluetooth_device_list)

        // Inicializar Bluetooth
        val bluetoothManager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = bluetoothManager.adapter

        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth no disponible", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        initializeViews()
        checkPermissions()
    }

    private fun initializeViews() {
        recyclerView = findViewById(R.id.devicesRecyclerView)
        scanButton = findViewById(R.id.scanButton)
        emptyStateLayout = findViewById(R.id.emptyStateLayout)

        recyclerView.layoutManager = LinearLayoutManager(this)

        scanButton.setOnClickListener {
            loadPairedDevices()
        }
    }

    private fun checkPermissions() {
        val permissionsNeeded = mutableListOf<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // Android 12+
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(Manifest.permission.BLUETOOTH_CONNECT)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN)
                != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(Manifest.permission.BLUETOOTH_SCAN)
            }
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        if (permissionsNeeded.isNotEmpty()) {
            ActivityCompat.requestPermissions(
                this,
                permissionsNeeded.toTypedArray(),
                REQUEST_BLUETOOTH_PERMISSIONS
            )
        } else {
            loadPairedDevices()
        }
    }

    private fun loadPairedDevices() {
        if (!hasBluetoothPermissions()) {
            Toast.makeText(this, "Se requieren permisos de Bluetooth", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val pairedDevices = bluetoothAdapter?.bondedDevices
            deviceList.clear()

            if (pairedDevices != null) {
                deviceList.addAll(pairedDevices)
            }

            if (deviceList.isEmpty()) {
                recyclerView.visibility = View.GONE
                emptyStateLayout.visibility = View.VISIBLE
            } else {
                recyclerView.visibility = View.VISIBLE
                emptyStateLayout.visibility = View.GONE
            }

            setupRecyclerView()

        } catch (e: SecurityException) {
            Toast.makeText(this, "Error de permisos: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupRecyclerView() {
        val adapter = BluetoothDeviceAdapter(deviceList) { device ->
            onDeviceSelected(device)
        }
        recyclerView.adapter = adapter
    }

    private fun onDeviceSelected(device: BluetoothDevice) {
        try {
            val intent = Intent()
            intent.putExtra(EXTRA_DEVICE_ADDRESS, device.address)
            intent.putExtra(EXTRA_DEVICE_NAME, device.name ?: "Unknown Device")
            setResult(RESULT_OK, intent)
            finish()
        } catch (e: SecurityException) {
            Toast.makeText(this, "Error al seleccionar dispositivo", Toast.LENGTH_SHORT).show()
        }
    }

    private fun hasBluetoothPermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) ==
                    PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == REQUEST_BLUETOOTH_PERMISSIONS) {
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                loadPairedDevices()
            } else {
                Toast.makeText(this, "Permisos necesarios para Bluetooth", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Adapter para el RecyclerView
    private class BluetoothDeviceAdapter(
        private val devices: List<BluetoothDevice>,
        private val onDeviceClick: (BluetoothDevice) -> Unit
    ) : RecyclerView.Adapter<BluetoothDeviceAdapter.ViewHolder>() {

        class ViewHolder(view: android.view.View) : RecyclerView.ViewHolder(view) {
            val deviceName: android.widget.TextView = view.findViewById(R.id.deviceNameTextView)
            val deviceAddress: android.widget.TextView = view.findViewById(R.id.deviceAddressTextView)
        }

        override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): ViewHolder {
            val view = android.view.LayoutInflater.from(parent.context)
                .inflate(R.layout.item_bluetooth_device, parent, false)
            return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val device = devices[position]
            try {
                holder.deviceName.text = device.name ?: "Unknown Device"
                holder.deviceAddress.text = device.address
                holder.itemView.setOnClickListener {
                    onDeviceClick(device)
                }
            } catch (e: SecurityException) {
                holder.deviceName.text = "Unknown Device"
                holder.deviceAddress.text = device.address
            }
        }

        override fun getItemCount() = devices.size
    }
}