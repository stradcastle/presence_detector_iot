package com.iot.presencedetector.service

import android.util.Log
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.iot.presencedetector.model.Event
import com.iot.presencedetector.model.User
import kotlinx.coroutines.tasks.await

/**
 * Servicio para manejar Firebase Authentication y Firestore
 */
class FirebaseService {

    companion object {
        private const val TAG = "FirebaseService"
        private const val USERS_COLLECTION = "users"
        private const val EVENTS_COLLECTION = "events"
    }

    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()

    /**
     * Obtiene el usuario actualmente autenticado
     */
    fun getCurrentUser(): FirebaseUser? = auth.currentUser

    /**
     * Verifica si hay un usuario autenticado
     */
    fun isUserLoggedIn(): Boolean = getCurrentUser() != null

    /**
     * Registra un nuevo usuario
     */
    suspend fun registerUser(
        email: String,
        password: String,
        displayName: String
    ): Result<FirebaseUser> {
        return try {
            // Crear usuario en Authentication
            val authResult = auth.createUserWithEmailAndPassword(email, password).await()
            val user = authResult.user ?: throw Exception("Usuario no creado")

            // Actualizar perfil con nombre
            val profileUpdates = UserProfileChangeRequest.Builder()
                .setDisplayName(displayName)
                .build()
            user.updateProfile(profileUpdates).await()

            // Crear documento en Firestore
            val userDoc = User(
                id = user.uid,
                email = email,
                displayName = displayName,
                createdAt = Timestamp.now(),
                lastLogin = Timestamp.now()
            )

            firestore.collection(USERS_COLLECTION)
                .document(user.uid)
                .set(userDoc)
                .await()

            Log.i(TAG, "Usuario registrado: ${user.email}")
            Result.success(user)

        } catch (e: Exception) {
            Log.e(TAG, "Error al registrar usuario: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Inicia sesión con email y contraseña
     */
    suspend fun loginUser(email: String, password: String): Result<FirebaseUser> {
        return try {
            val authResult = auth.signInWithEmailAndPassword(email, password).await()
            val user = authResult.user ?: throw Exception("Usuario no encontrado")

            // Actualizar última conexión
            firestore.collection(USERS_COLLECTION)
                .document(user.uid)
                .update("lastLogin", Timestamp.now())
                .await()

            Log.i(TAG, "Usuario autenticado: ${user.email}")
            Result.success(user)

        } catch (e: Exception) {
            Log.e(TAG, "Error al iniciar sesión: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Cierra la sesión del usuario actual
     */
    fun logout() {
        auth.signOut()
        Log.i(TAG, "Sesión cerrada")
    }

    /**
     * Registra un evento en Firestore
     */
    suspend fun logEvent(
        eventType: String,
        estado: Int,
        estadoTexto: String,
        movimiento: Boolean,
        deviceName: String
    ): Result<String> {
        return try {
            val user = getCurrentUser() ?: throw Exception("Usuario no autenticado")

            val event = Event(
                userId = user.uid,
                eventType = eventType,
                estado = estado,
                estadoTexto = estadoTexto,
                movimiento = movimiento,
                timestamp = Timestamp.now(),
                deviceName = deviceName
            )

            val documentRef = firestore.collection(EVENTS_COLLECTION)
                .add(event)
                .await()

            Log.i(TAG, "Evento registrado: $eventType")
            Result.success(documentRef.id)

        } catch (e: Exception) {
            Log.e(TAG, "Error al registrar evento: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Obtiene el historial de eventos del usuario
     */
    suspend fun getEventHistory(limit: Int = 50): Result<List<Event>> {
        return try {
            val user = getCurrentUser() ?: throw Exception("Usuario no autenticado")

            val events = firestore.collection(EVENTS_COLLECTION)
                .whereEqualTo("userId", user.uid)
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .limit(limit.toLong())
                .get()
                .await()
                .toObjects(Event::class.java)

            Log.i(TAG, "Eventos obtenidos: ${events.size}")
            Result.success(events)

        } catch (e: Exception) {
            Log.e(TAG, "Error al obtener eventos: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Alias para getEventHistory (compatibilidad con EventHistoryActivity)
     */
    suspend fun getEvents(limit: Int = 50): Result<List<Event>> {
        return getEventHistory(limit)
    }

    /**
     * Obtiene los datos del usuario desde Firestore
     */
    suspend fun getUserData(): Result<User> {
        return try {
            val user = getCurrentUser() ?: throw Exception("Usuario no autenticado")

            val userDoc = firestore.collection(USERS_COLLECTION)
                .document(user.uid)
                .get()
                .await()

            val userData = userDoc.toObject(User::class.java)
                ?: throw Exception("Datos de usuario no encontrados")

            Result.success(userData)

        } catch (e: Exception) {
            Log.e(TAG, "Error al obtener datos de usuario: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Actualiza el nombre del usuario
     */
    suspend fun updateDisplayName(newName: String): Result<Unit> {
        return try {
            val user = getCurrentUser() ?: throw Exception("Usuario no autenticado")

            // Actualizar en Authentication
            val profileUpdates = UserProfileChangeRequest.Builder()
                .setDisplayName(newName)
                .build()
            user.updateProfile(profileUpdates).await()

            // Actualizar en Firestore
            firestore.collection(USERS_COLLECTION)
                .document(user.uid)
                .update("displayName", newName)
                .await()

            Log.i(TAG, "Nombre actualizado: $newName")
            Result.success(Unit)

        } catch (e: Exception) {
            Log.e(TAG, "Error al actualizar nombre: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Elimina eventos antiguos (más de 30 días)
     */
    suspend fun cleanOldEvents(): Result<Int> {
        return try {
            val user = getCurrentUser() ?: throw Exception("Usuario no autenticado")
            val thirtyDaysAgo = Timestamp(System.currentTimeMillis() / 1000 - (30 * 24 * 60 * 60), 0)

            val oldEvents = firestore.collection(EVENTS_COLLECTION)
                .whereEqualTo("userId", user.uid)
                .whereLessThan("timestamp", thirtyDaysAgo)
                .get()
                .await()

            var deletedCount = 0
            for (document in oldEvents.documents) {
                document.reference.delete().await()
                deletedCount++
            }

            Log.i(TAG, "Eventos antiguos eliminados: $deletedCount")
            Result.success(deletedCount)

        } catch (e: Exception) {
            Log.e(TAG, "Error al limpiar eventos antiguos: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Elimina la cuenta del usuario actual
     */
    suspend fun deleteAccount(): Result<Unit> {
        return try {
            val user = getCurrentUser() ?: throw Exception("Usuario no autenticado")
            val userId = user.uid

            // Eliminar todos los eventos del usuario
            val events = firestore.collection(EVENTS_COLLECTION)
                .whereEqualTo("userId", userId)
                .get()
                .await()

            for (document in events.documents) {
                document.reference.delete().await()
            }

            // Eliminar documento del usuario en Firestore
            firestore.collection(USERS_COLLECTION)
                .document(userId)
                .delete()
                .await()

            // Eliminar usuario de Authentication
            user.delete().await()

            Log.i(TAG, "Cuenta eliminada: $userId")
            Result.success(Unit)

        } catch (e: Exception) {
            Log.e(TAG, "Error al eliminar cuenta: ${e.message}", e)
            Result.failure(e)
        }
    }
}