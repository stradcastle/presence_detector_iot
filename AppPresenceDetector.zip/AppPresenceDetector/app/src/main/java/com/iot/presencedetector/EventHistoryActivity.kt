package com.iot.presencedetector

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.iot.presencedetector.model.Event
import com.iot.presencedetector.service.FirebaseService
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class EventHistoryActivity : AppCompatActivity() {

    private lateinit var firebaseService: FirebaseService

    private lateinit var backButton: ImageButton
    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var emptyTextView: TextView
    private lateinit var refreshButton: Button

    private val events = mutableListOf<Event>()
    private lateinit var adapter: EventAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_event_history)

        firebaseService = FirebaseService()

        initViews()
        setupRecyclerView()
        loadEvents()
    }

    private fun initViews() {
        backButton = findViewById(R.id.backButton)
        recyclerView = findViewById(R.id.eventsRecyclerView)
        progressBar = findViewById(R.id.progressBar)
        emptyTextView = findViewById(R.id.emptyTextView)
        refreshButton = findViewById(R.id.refreshButton)

        backButton.setOnClickListener {
            finish()
        }

        refreshButton.setOnClickListener {
            loadEvents()
        }
    }

    private fun setupRecyclerView() {
        adapter = EventAdapter(events)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
    }

    private fun loadEvents() {
        progressBar.visibility = View.VISIBLE
        emptyTextView.visibility = View.GONE

        lifecycleScope.launch {
            val result = firebaseService.getEvents(limit = 50)

            progressBar.visibility = View.GONE

            result.onSuccess { eventList ->
                events.clear()
                events.addAll(eventList)
                adapter.notifyDataSetChanged()

                if (events.isEmpty()) {
                    emptyTextView.visibility = View.VISIBLE
                    emptyTextView.text = "No hay eventos registrados"
                }
            }.onFailure { e ->
                emptyTextView.visibility = View.VISIBLE
                emptyTextView.text = "Error al cargar eventos: ${e.message}"
                Toast.makeText(
                    this@EventHistoryActivity,
                    "Error: ${e.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    // Adapter para RecyclerView
    private inner class EventAdapter(private val events: List<Event>) :
        RecyclerView.Adapter<EventAdapter.EventViewHolder>() {

        private val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())

        inner class EventViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val eventTypeTextView: TextView = itemView.findViewById(R.id.eventTypeTextView)
            val eventTimeTextView: TextView = itemView.findViewById(R.id.eventTimeTextView)
            val eventStateTextView: TextView = itemView.findViewById(R.id.eventStateTextView)
            val eventDeviceTextView: TextView = itemView.findViewById(R.id.eventDeviceTextView)
            val eventIcon: ImageView = itemView.findViewById(R.id.eventIcon)
        }

        override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): EventViewHolder {
            val view = android.view.LayoutInflater.from(parent.context)
                .inflate(R.layout.item_event, parent, false)
            return EventViewHolder(view)
        }

        override fun onBindViewHolder(holder: EventViewHolder, position: Int) {
            val event = events[position]

            holder.eventTypeTextView.text = event.eventType
            holder.eventTimeTextView.text = dateFormat.format(event.timestamp.toDate())
            holder.eventStateTextView.text = "Estado: ${event.estadoTexto}"
            holder.eventDeviceTextView.text = event.deviceName.ifEmpty { "Sin dispositivo" }

            // Configurar icono según tipo de evento
            val iconRes = when {
                event.eventType.contains("MOVIMIENTO") -> android.R.drawable.ic_dialog_alert
                event.eventType.contains("CAMBIO") -> android.R.drawable.ic_menu_edit
                else -> android.R.drawable.ic_menu_info_details
            }
            holder.eventIcon.setImageResource(iconRes)

            // Color según si hubo movimiento
            val backgroundColor = if (event.movimiento) {
                android.R.color.holo_red_light
            } else {
                android.R.color.white
            }
            holder.itemView.setBackgroundColor(
                holder.itemView.context.getColor(backgroundColor)
            )
        }

        override fun getItemCount(): Int = events.size
    }
}