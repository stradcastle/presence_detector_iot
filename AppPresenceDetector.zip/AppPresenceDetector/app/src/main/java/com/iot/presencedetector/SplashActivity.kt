package com.iot.presencedetector

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.iot.presencedetector.service.FirebaseService

/**
 * Pantalla de splash inicial
 */
@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {

    private val firebaseService = FirebaseService()
    private val splashDuration = 2000L // 2 segundos

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // Navegar después del splash
        Handler(Looper.getMainLooper()).postDelayed({
            navigateToNextScreen()
        }, splashDuration)
    }

    private fun navigateToNextScreen() {
        val intent = if (firebaseService.isUserLoggedIn()) {
            // Usuario ya autenticado, ir a MainActivity
            Intent(this, MainActivity::class.java)
        } else {
            // No hay usuario, ir a Login
            Intent(this, LoginActivity::class.java)
        }

        startActivity(intent)
        finish()
    }
}